import { Component } from "@angular/core";
import { customersService } from "../services/customers.service";
import errCallBack from "../common/errCallBack";
import Customers from '../common/Customers';
@Component({
    selector:"customers",
    templateUrl:"./customers.component.html"
})
export class customersComponent{
    private result:Customers[];
    constructor(private _service:customersService){}
    ngOnInit(){
        this._service.getCustomers()
            .subscribe((posRes)=>{
                this.result = posRes;
            },errCallBack);
    };
};