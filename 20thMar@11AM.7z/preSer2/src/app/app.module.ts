import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { customersComponent } from './components/customers.component';
import { HttpClientModule } from '@angular/common/http';
import { customersService } from './services/customers.service';
@NgModule({
  declarations: [
    AppComponent,customersComponent
  ],
  imports: [
    BrowserModule,HttpClientModule
  ],
  providers: [customersService],
  bootstrap: [customersComponent]
})
export class AppModule { }
