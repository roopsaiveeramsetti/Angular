import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { Observable } from "rxjs-compat";
import "rxjs/Rx";
import Customers from '../common/Customers';
import CUSTOMERS from '../common/URLS';
@Injectable()
export class customersService{
    constructor(private _http:HttpClient){}
    public getCustomers():Observable<Customers[]>{
        return this._http.get(CUSTOMERS)
                   .pipe(map((res:Response)=>{
                       return <Customers[]>res.records;
                   }));
    };
};
