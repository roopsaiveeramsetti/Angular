interface Customers{
    Name:string;
    City:string;
    Country:string;
};
export default Customers;