import { Component } from "@angular/core";
import { customersService } from '../services/customers.service';
import { countriesService } from '../services/countries.service';
import errCallBack from '../common/errCallBack';
@Component({
    selector:"series",
    templateUrl:"./series.component.html"
})
export class seriesComponent{
    private res_one:any;
    private res_two:any;
    constructor(private _service1:customersService,
                private _service2:countriesService){
    };
    ngOnInit(){
        this._service1.getCustomers().subscribe((res1)=>{
            this.res_one = res1;
            /***************************************/
                this._service2.getCountries()
                              .subscribe((res2)=>{
                    this.res_two = res2;
                },errCallBack);
            /***************************************/
        },errCallBack);
    };
};