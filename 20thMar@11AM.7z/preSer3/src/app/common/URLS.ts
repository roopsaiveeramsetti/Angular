let URLS = {
    CUSTOMERS : "https://www.w3schools.com/angular/customers.php",
    COUNTRIES : "https://restcountries.eu/rest/v2/all"

};
export default URLS;