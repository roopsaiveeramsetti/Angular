import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { seriesComponent } from './components/series.component';
import { customersService } from './services/customers.service';
import { countriesService } from './services/countries.service';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,seriesComponent
  ],
  imports: [
    BrowserModule,HttpClientModule
  ],
  providers: [customersService,countriesService],
  bootstrap: [seriesComponent]
})
export class AppModule { }
