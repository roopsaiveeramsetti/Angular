//import Component
//Component is used to convert the TS Standards to HTML Standards
import { Component } from "@angular/core";
//import countriesService
//getCountries() function present in countriesService
//getCountries() function return Rest Data
import { countriesService } from "../services/countries.service";
import { HttpErrorResponse } from '@angular/common/http';
//use Component
@Component({
    selector:"countries",
    templateUrl:"./countries.component.html"
})
//export class
export class countriesComponent{
    //declare result variable
    private result:any;
    //create the reference to countriesService
    //Dependency Injection
    constructor(private _service:countriesService){}
    //first life cycle hook
    //ngOnInit()
    //first life cycle hook used to write the business logic
    ngOnInit(){
        this._service.getCountries().subscribe((posRes)=>{
                this.result = posRes;
        },(errRes:HttpErrorResponse)=>{
            if(errRes.error instanceof Error){
                console.log("Client Side Errors !!!");
            }else{
                console.log("Server Side Errors !!!");
            }
        });
    };
};