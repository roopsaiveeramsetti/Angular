//import json object from db_connection
//getConnection is the key in json object
//getConnection return mysql connection object
var json_obj = require("../config/db_connection");
//get the connection object
var connection = json_obj.getConnection();
//connect to database
connection.connect();
//import express module
var express = require("express");
//create the router instance
//router instance used to make the modules
var router = express.Router();
//create the Rest API
router.get("/",(req,res)=>{
    //fetch the data from employees table
    connection.query("select * from employees",
                            (err,recordsArray,fields)=>{
        res.send(recordsArray);
    });
});
//export module
module.exports = router;