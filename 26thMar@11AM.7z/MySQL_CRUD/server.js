var express = require("express");
var bodyparser = require("body-parser");
var cors = require("cors");

var app = express();

//set the JSON As MIME Type
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));

//enable the ports communication
app.use(cors());

var module1 = require("./fetch/fetch");
app.use("/fetch",module1);

var module2 = require("./insert/insert");
app.use("/insert",module2);

var module3 = require("./update/update");
app.use("/update",module3);

var module4 = require("./delete/delete");
app.use("/delete",module4);

app.listen(8080);
console.log("Server Listening the port no.8080");
