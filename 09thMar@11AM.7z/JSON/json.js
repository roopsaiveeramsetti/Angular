/*
let obj:any = {
    sub_one     :      "Angular8",
    sub_two     :      "NodeJS",
    sub_three   :      "MongoDB"
};
document.write( obj.sub_one+"<br>"+
                obj.sub_two+"<br>"+
                obj.sub_three );
*/
/*
let obj:any = {
    oracle:():string=>{ return "Oracle Connection Soon...!" },
    mysql :():string=>{ return "MySQL Connection Soon...!" },
    mongodb:():string=>{ return "MongoDB Connection Soon...!" },
    sqlserver:():string=>{ return "SQL Server Connection Soon...!" }
};
document.write( obj.oracle()+"<br>"+
                obj.mysql()+"<br>"+
                obj.mongodb()+"<br>"+
                obj.sqlserver() );
*/
/*
let employees:Array<any> = [
    {"e_id":111,"e_name":"e_one","e_sal":10000},
    {"e_id":222,"e_name":"e_two","e_sal":20000},
    {"e_id":333,"e_name":"e_three","e_sal":30000},
    {"e_id":444,"e_name":"e_four","e_sal":40000},
    {"e_id":555,"e_name":"e_five","e_sal":50000}
];
for(let i:number=0;i<employees.length;i++){
    let obj:any = employees[i];
    document.write( obj.e_id+"..."+obj.e_name+"..."+obj.e_sal +"<br>");
};
*/
var obj = { "p_id": 111, "p_name": "p_one", "p_cost": 10000 };
var array = Object.keys(obj);
for (var i = 0; i < array.length; i++) {
    document.write(array[i] + "<br>");
}
;
