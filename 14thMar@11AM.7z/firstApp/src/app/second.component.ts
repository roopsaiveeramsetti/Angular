import { Component } from "@angular/core";
@Component({
    selector:"second",
    templateUrl:"./second.component.html"
})
export class secondComponent{
    public mongodbData():string{
        return "MongoDB Data Soon...!";
    };
};