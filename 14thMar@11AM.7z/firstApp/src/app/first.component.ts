import { Component } from "@angular/core";
@Component({
    selector:"first",
    templateUrl:"./first.component.html"
})
export class firstComponent{
    public mySQLData():string{
        return "MySQL Data Soon...!";
    };
};