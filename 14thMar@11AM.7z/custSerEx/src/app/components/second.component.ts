import { Component } from "@angular/core";
import { myService } from "../services/my.service";
@Component({
    selector:"second",
    templateUrl:"./second.component.html"
})
export class secondComponent{
    private result:string;
    constructor(private _service:myService){}
    ngOnInit(){
        this.result = this._service.mongodbData();
    };
};