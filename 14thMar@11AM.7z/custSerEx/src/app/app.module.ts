import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { firstComponent } from './components/first.component';
import { secondComponent } from './components/second.component';
import { myService } from './services/my.service';
@NgModule({
  declarations: [
    AppComponent,firstComponent,secondComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [myService],
  bootstrap: [firstComponent]
})
export class AppModule { }
