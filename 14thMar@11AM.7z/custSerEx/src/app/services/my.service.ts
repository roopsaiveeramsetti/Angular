import { Injectable } from "@angular/core";
@Injectable()
export class myService{
    public mySQLData():string{
        return "MySQL Data Soon...!";
    };
    public mongodbData():string{
        return "MongoDB Data Soon...!";
    };
};