var express = require("express");
var mongodb = require("mongodb");
var router = express.Router();
var nareshIT = mongodb.MongoClient;
router.post("/",(req,res)=>{
    var delete_obj = {"e_id":req.body.e_id};
    nareshIT.connect("mongodb://localhost:27017/crud",
                        (err,db)=>{
        db.collection("employees").deleteOne(delete_obj,
                            (err,result)=>{
            if(err){
                res.send({"delete":"fail"});
            }else{
                res.send({"delete":"success"});
            }
        });
    });
});
module.exports = router;