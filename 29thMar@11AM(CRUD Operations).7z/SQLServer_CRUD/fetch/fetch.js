//import express module
//express module used to develop the Rest API'S
var obj = require("../common");
var express = obj.key1;
//import mssql module
//mssql module used to connect to SQLServer
var mssql = obj.key2;
//import db_properties
//db_properties containes database properties
var obj = require("../config/db_properties");
//create the router instance
//router instance used to make the modules
var router = express.Router();
//create the Rest API
router.get("/",(req,res)=>{
    //connect to SQLServer
    mssql.connect(obj,(err)=>{
        if(err){
            console.log("Connection Denied !!!");
        }else{
            //create the query object
            var request = new mssql.Request();
            //where "request" object used to write the SQL Queries

            //query the table
            request.query("select * from employees",(err,records)=>{
                if(err){
                    console.log("Error !!!");
                }else{
                    res.send(records.recordsets[0]);
                }
                //close the mssql connection
                mssql.close();
            });
        }
    });
});
//export the router
module.exports = router;