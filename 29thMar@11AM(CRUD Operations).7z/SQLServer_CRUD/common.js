module.exports = {key1:require("express"),
                  key2:require("mssql")};