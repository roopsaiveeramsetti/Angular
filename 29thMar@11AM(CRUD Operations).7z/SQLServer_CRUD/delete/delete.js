var express = require("express");
var mssql = require("mssql");
var obj = require("../config/db_properties");
var router = express.Router();
router.post("/",(req,res)=>{
    mssql.connect(obj,(err)=>{
        if(err){
            console.log("Connection Denied !!!");
        }else{
            var e_id = req.body.e_id;
            var request = new mssql.Request();
            request.query("delete from employees where e_id="+e_id,
                        (err,result)=>{
                if(err){
                    res.send({"delete":"fail"});
                }else{
                    res.send({"delete":"success"});
                }
                mssql.close();
            });
        }
    });
});
module.exports = router;