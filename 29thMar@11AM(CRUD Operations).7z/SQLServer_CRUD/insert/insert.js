var express = require("express");
var mssql = require("mssql");
var obj = require("../config/db_properties");
var router = express.Router();
router.post("/",(req,res)=>{
    mssql.connect(obj,(err)=>{
        if(err){
            console.log("Connection Denied !!!");
        }else{
            var e_id = req.body.e_id;
            var e_name = req.body.e_name;
            var e_sal = req.body.e_sal;

            var request = new mssql.Request();
            request.query("insert into employees values("+e_id+",'"+e_name+"',"+e_sal+")",(err,result)=>{
                if(err){
                    res.send({"insert":"fail"});
                }else{
                    res.send({"insert":"success"});
                }
                mssql.close();
            });
        }
    });
});
module.exports = router;




