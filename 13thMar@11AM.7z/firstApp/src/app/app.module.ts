//BrowserModule is the Predefined Class
//BrowserModule is the Predefined library
//BrowserModule helps to execute the Projects into different Browsers
import { BrowserModule } from '@angular/platform-browser';
//NgModule is the Predefined Class
//NgModule used to create the Custom Modules
import { NgModule } from '@angular/core';
//AppComponent is the Default Component
//AppComponent Created by Angular Framework
import { AppComponent } from './app.component';
//import FirstComponent
import { FirstComponent } from "./first.component";
//we have following arrays @declarations,@imports,@providers,@bootstrap
//declarations array used to register the components,pipes,directives.
//imports array used to register the modules
//providers used to register the services
//bootstrap used to execute the particular component
@NgModule({
  declarations: [
    AppComponent,FirstComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [FirstComponent]
})
export class AppModule { }