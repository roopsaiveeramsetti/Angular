/*
    - Component is the Predefined Class.
    - Component class available in @angular/core      
      package.
    - Component class used to convert the TypeScript
      Standards to Equalent HTML Standards.
    - we will use Predefined Classes by using "@".
    - using Predefined classes by using "@" symbol    
      called as Decorator.
    - Decorators are used to define the Metadata
    - Component class constructor takes the JSON     
      Object.
    - selector is the key used to define the custom    
      HTML Element 
    - where "first" is the custom HTML Element.
    - we will call custom HTML Element in "index.html"   file.
    - templateUrl is used to link the external    
      templates to Component. 
    - "export" is the predefined key in TypeScript.
    - "export" key used to export the Classes,
       functions,modules,......
    - anyone can import the exported members.
*/
import { Component } from "@angular/core";
@Component({
    selector:"first",
    templateUrl:"./first.component.html"
})
export class FirstComponent{
    private sub_one:string;
    private sub_two:string;
    private sub_three:string;
    constructor(){
        this.sub_one = "Angular8";
        this.sub_two = "NodeJS";
        this.sub_three = "MongoDB";
    };
    public getSubOne():string{
        return this.sub_one;
    };
    public getSubTwo():string{
        return this.sub_two;
    };
    public getSubThree():string{
        return this.sub_three;
    };
};