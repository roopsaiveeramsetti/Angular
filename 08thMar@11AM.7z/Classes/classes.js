/*
abstract class class_one{
    fun_one():string{
        return "I am from fun one !!!";
    };
    abstract fun_two():string;
};
class class_two extends class_one{
    fun_two():string{
        return "I am from fun two !!!";
    };
};
let obj:class_two = new class_two();
document.write( obj.fun_one() + "<br>" + obj.fun_two() );
*/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/*
abstract class class_one{
    abstract fun_one():string;
};
abstract class class_two extends class_one{
    abstract fun_two():string;
};
abstract class class_three extends class_two{
    abstract fun_three():string;
};
class my_class extends class_three{
    fun_one():string{
        return "Oracle Data Soon...!";
    };
    fun_two():string{
        return "MySQL Data Soon...!";
    };
    fun_three():string{
        return "MongoDB Data Soon...!";
    };
};
var obj:my_class = new my_class();
document.write( obj.fun_one()+"<br>"+
                obj.fun_two()+"<br>"+
                obj.fun_three() );
*/
/*
interface myInterface{
    fun_one():string;
};
abstract class class_one implements myInterface{
    fun_one():string{
        return "Oracle Data Soon...!";
    };
    abstract fun_two():string;
};
class class_two extends class_one{
    fun_two():string{
        return "MySQL Data Soon...!";
    };
};
var obj:class_two = new class_two();
document.write( obj.fun_one()+"<br>"+obj.fun_two() );
*/
/*
class class_one{
    sub:string;
    constructor(arg1:string){
        this.sub = arg1;
    };
};
class class_two extends class_one{
    constructor(){
        super("Angular8");
    };
};
let obj:class_two = new class_two();
document.write( obj.sub );
*/
/*
class class_one{
    sub_one:string;
    constructor(arg1:string){
        this.sub_one = arg1;
    };
};
class class_two extends class_one{
    sub_two:string;
    constructor(param1:string,param2:string){
        super(param1);
        this.sub_two = param2;
    };
};
let obj:class_two = new class_two("AngularJS","Angular8");
document.write( obj.sub_one+"<br>" + obj.sub_two );
*/
/*
class class_one{
    fun_one():string{
        return "I am from class one !!!";
    };
};
class class_two extends class_one{
    fun_two():string{
        return super.fun_one();
    };
};
var obj:class_two = new class_two();
document.write( obj.fun_two() );
*/
/*
    static
    - static members we can access directly with class names.
    - for static members memory will be allotted in heap area.
    - we can't initilize static members through constructors in TypeScript.
    - we can't access static members through class objects.
*/
/*
class class_one{
    static sub:string = "Angular8";
    //constructor(){
      //  this.sub = "Angular8";
    //};
    static getSub():string{
        return this.sub;
    };
};
document.write( class_one.sub +"<br>"+ class_one.getSub() );
//let obj:class_one = new class_one();
//obj.sub;
*/
/*
    readonly
        - readonly members we can only read the content but we
          can't update it.

        - readonly members we can initilize by using constructors.
*/
/*
class class_one{

    readonly sub:string;

    constructor(arg1:string){
        this.sub = arg1;
    };

};
let obj:class_one = new class_one("Angular8");
document.write( obj.sub );
//obj.sub = "ReactJS";
*/
/*
    private:
    -------
        private members can't access out of class.
        
        private members we can access with in the class by using
        this keyword.
        
        private members we can't access throgh class references.
        
        the recomended modifier for variables is private because
        of secuirity
*/
/*
class class_one{
    private sub_one:string;
    private sub_two:string;
    private sub_three:string;
    constructor(){
        this.sub_one = "Angular8";
        this.sub_two = "NodeJS";
        this.sub_three = "MongoDB";
    };
    private myFun():string{
        return this.sub_one+"<==>"+
               this.sub_two+"<==>"+
               this.sub_three;
    };
    public getSubjects():string{
        return this.myFun();
    };
};
var obj:class_one = new class_one();
document.write( obj.getSubjects() );
*/
/*
    protected:
            protected members available to child classes.
            we can't access protected members by using class references.
*/
var class_one = /** @class */ (function () {
    function class_one() {
    }
    class_one.prototype.fun_one = function () {
        return "I am from class one !!!";
    };
    ;
    return class_one;
}());
;
var class_two = /** @class */ (function (_super) {
    __extends(class_two, _super);
    function class_two() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    class_two.prototype.fun_two = function () {
        return this.fun_one();
    };
    ;
    return class_two;
}(class_one));
;
var obj = new class_two();
document.write(obj.fun_two());
