var express = require("express");
var mongodb = require("mongodb");
var nareshIT = mongodb.MongoClient;
var router = express.Router();
router.post("/",(req,res)=>{
    var conditional_obj = {"e_id":req.body.e_id};
    var update_obj = {$set:{"e_name":req.body.e_name,
                            "e_sal":req.body.e_sal}};
    nareshIT.connect("mongodb://localhost:27017/crud",
                        (err,db)=>{
        db.collection("employees").updateOne(conditional_obj,update_obj,(err,result)=>{
            if(err){
                res.send({"update":"fail"});
            }else{
                res.send({"update":"success"});
            }
        });
    });
});
module.exports = router;