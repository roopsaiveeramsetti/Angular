//import express module
//express module used to develop the Rest API'S
var express = require("express");
//import mongodb module
//mongodb module used to interact with the mongodb database
var mongodb = require("mongodb");
//create the router instance
//router instance helps to create the module
var router = express.Router();
//create the client
//mongodb follows the client server architecture
//where "nareshIT" is the client
var nareshIT = mongodb.MongoClient;
//create the Rest API
router.get("/",(req,res)=>{
    nareshIT.connect("mongodb://localhost:27017/crud",
                            (err,db)=>{
        db.collection("employees").find()
                            .toArray((err,array)=>{
            res.send(array);
        });
    });
});
//export router
module.exports = router;