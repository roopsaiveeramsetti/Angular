/*
class class_one{

    private sub_one:string;
    private sub_two:string;
    private sub_three:string;

    constructor(){
        this.sub_one = "Angular8";
        this.sub_two = "NodeJS";
        this.sub_three = "MongoDB";
    };

    public myFun():void{
        document.write(this.sub_one+"<==>"+
                       this.sub_two+"<==>"+
                       this.sub_three);
    };
};

var obj:class_one = new class_one();
obj.myFun();
*/
/*
class class_one{
    private sub_one:string;
    private sub_two:string;
    private sub_three:string;
    constructor(){
        this.sub_one = "Angular8";
        this.sub_two = "NodeJS";
        this.sub_three = "MongoDB";
    };
    public getSubOne():string{
        return this.sub_one;
    };
    public getSubTwo():string{
        return this.sub_two;
    };
    public getSubThree():string{
        return this.sub_three;
    };
};
var obj:class_one = new class_one();
document.write( obj.getSubOne()+"<br>"+
                obj.getSubTwo()+"<br>"+
                obj.getSubThree() );
*/

/*
class class_one{
    private sub_one:string;
    private sub_two:string;
    private sub_three:string;

    constructor(arg1:string,arg2:string,arg3:string){
        this.sub_one = arg1;
        this.sub_two = arg2;
        this.sub_three = arg3;
    }

    public myFun():void{
        document.write(this.sub_one+"<br>"+this.sub_two+"<br>"+this.sub_three+"<br>");
    };
};

var obj:class_one = new class_one("AngularJS","NodeJS","MySQL");
obj.myFun();
*/
/*
class class_one{
    public myFun():any{
        return new class_two();
    };
};
class class_two{
    public myFun():string{
        return "Welcome...!";
    };
};
document.write( new class_one().myFun().myFun() );
*/

/*
class class_one{
    private obj1:class_two;
    private obj2:class_three;
    private obj3:class_four;

    constructor(arg1:class_two,
                arg2:class_three,
                arg3:class_four){
        this.obj1 = arg1;
        this.obj2 = arg2;
        this.obj3 = arg3;
    }

    public getData():void{
        document.write( this.obj1.getData() +"<br>" +
                        this.obj2.getData() +"<br>" +
                        this.obj3.getData() );
    };
};

class class_two{
    public getData():string{
        return "Angular8";
    };
};

class class_three{
    public getData():string{
        return "NodeJS";
    };
};

class class_four{
    public getData():string{
        return "MongoDB";
    };
};

var obj:class_one = new class_one(  new class_two(),
                                    new class_three(),
                                    new class_four() );
obj.getData();
*/

/*
class class_one{
    public fun_one():string{
        return "I am from class one !!!";
    };
};
class class_two extends class_one{
    public fun_two():string{
        return "I am from class two !!!";
    };
};
var obj:class_two = new class_two();
document.write( obj.fun_one()+"<br>"+
                obj.fun_two() );
*/

/*
class class_one{
    public fun_one():string{
        return "I am from class one !!!";
    };
};
class class_two extends class_one{
    public fun_two():string{
        return "I am from class two !!!";
    };
};
class class_three extends class_two{
    public fun_three():string{
        return "I am from class three !!!";
    };
};
var obj1:class_one = new class_one();
document.write(obj1.fun_one()+"<br>");

var obj2:class_two = new class_two();
document.write(obj2.fun_one()+"<br>"+obj2.fun_two()+"<br>");

let obj3:class_three = new class_three();
document.write( obj3.fun_one()+"<br>"+
                obj3.fun_two()+"<br>"+
                obj3.fun_three());


let tc1:class_one = new class_two();
document.write(tc1.fun_one()+"<br>");
*/

/*
class class_one{}
class class_two{}
class class_three extends class_one,class_two{}

    Note : multiple inheritance not supported by TypeScript.
*/

















