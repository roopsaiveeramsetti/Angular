/*
class class_one{
    public add(arg1:number,arg2:number):number{
        return arg1+arg2;
    };
    public add(arg1:number,arg2:number,arg3:number):number{
        return arg1+arg2+arg3;
    };
};
    - same function name with different signatures called as function
      overloading.

    - function overloading not supported by TypeScript.

    - we can implement function overloading in TypeScript by
      using spread operator (...)
*/
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/*
class class_one{
    dbFun():string{
        return "Data From MongoDB Soon...!";
    };
};
class class_two extends class_one{
    dbFun():string{
        return "Data From CassandraDB Soon...!";
    };
};
var obj:class_two = new class_two();
document.write( obj.dbFun() );

    overriding the parent class functionality with child class
    functionality called as function overriding.

    we will implement function overriding with the help of inheritance.

    "function overloading" & "function overriding" are the forms of
    ploymorphism

*/
/*
interface myInterface{
    wish:string;
};
let obj:myInterface = {
    wish    :   "welcome to interfaces !!!"
};
document.write( obj.wish );
*/
/*
interface myInterface{
    sub_one:string;
    getSubOne():string;
};
let obj:myInterface = {
    sub_one : "Angular8",
    getSubOne: ():string=>{ return obj.sub_one }
};
document.write( obj.sub_one +"<br>" +
                obj.getSubOne() );
*/
/*
interface myInterface{
    getOracleConnection():string;
    getMySQLConnection():string;
    getMongoDBConnection():string;
    getCassandraDBConnection():string;
};
class dbClass implements myInterface{
    getOracleConnection():string{
        return "Oracle Connection Soon...!";
    };
    getMySQLConnection():string{
        return "MySQL Connection Soon...!";
    };
    getMongoDBConnection():string{
        return "MongoDB Connection Soon...!";
    };
    getCassandraDBConnection():string{
        return "CassandraDB Connection Soon...!";
    };
};
var obj:dbClass = new dbClass();
document.write( obj.getOracleConnection()+"<br>"+
                    obj.getMySQLConnection()+"<br>"+
                    obj.getMongoDBConnection()+"<br>"+
                    obj.getCassandraDBConnection());
*/
/*
interface interface1{
    oracleDB():string;
};
interface interface2 extends interface1{
    mysqlDB():string;
};
let obj:interface2 = {
    oracleDB : ():string=>{ return "Oracle DB Data Soon...!"},
    mysqlDB  : ():string=>{ return "MySQL DB Data Soon...!"}
};
document.write(obj.oracleDB()+"<br>"+
               obj.mysqlDB())
*/
/*
interface interface1{
    fun_one():string;
};
interface interface2 extends interface1{
    fun_two():string;
};
interface interface3 extends interface2{
    fun_three():string;
};
class mInheritance implements interface3{
    fun_one():string{
        return "I am from fun one !!!";
    };
    fun_two():string{
        return "I am from fun two !!!";
    };
    fun_three():string{
        return "I am from fun three !!!";
    };
};
let obj:mInheritance = new mInheritance();
document.write( obj.fun_one()+"<br>"+obj.fun_two()+"<br>"+obj.fun_three());
*/
/*
interface interface1{
    fun_one():string;
};
interface interface2{
    fun_two():string;
};
interface interface3 extends interface1,interface2{
    fun_three():string;
};
class mulInheritance implements interface3{
    fun_one():string{
        return "I am from interface 1";
    };
    fun_two():string{
        return "I am from interface 2";
    };
    fun_three():string{
        return "I am from interface 3";
    };
};
let obj:mulInheritance = new mulInheritance();
document.write( obj.fun_one()+"<br>"+obj.fun_two()+"<br>"+obj.fun_three());
*/
var class_one = /** @class */ (function () {
    function class_one() {
    }
    class_one.prototype.fun_one = function () {
        return "I am from fun one !!!";
    };
    ;
    return class_one;
}());
;
var class_two = /** @class */ (function (_super) {
    __extends(class_two, _super);
    function class_two() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    class_two.prototype.fun_two = function () {
        return "I am from fun two !!!";
    };
    ;
    return class_two;
}(class_one));
;
var obj = new class_two();
document.write(obj.fun_one() + "<br>" + obj.fun_two());
