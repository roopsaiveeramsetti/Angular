import { Component } from "@angular/core";
import { customersService } from "../services/customers.service";
import { HttpErrorResponse } from "@angular/common/http";
import Customers from "../common/Customers";
import errCallBack from '../common/errCallBack';
@Component({
    selector:"customers",
    templateUrl:"./customers.component.html"
})
export class customersComponent{
    private _result:Customers[];
    constructor(private _service:customersService){}
    ngOnInit(){
        this._service.getCustomers()
                     .subscribe(posRes=>{
                        this._result = posRes;
                     },errCallBack);
    };
};