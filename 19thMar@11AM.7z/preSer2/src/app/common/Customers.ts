interface Customers{
    Name:string;
    City:String;
    Country:String;
};
export default Customers;