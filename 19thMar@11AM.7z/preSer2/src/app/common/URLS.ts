const CUSTOMERS_URL:string = "https://www.w3schools.com/angular/customers.php";
export default CUSTOMERS_URL;