//import Injectable
//Injectable is used to create the Custom Services.
import { Injectable } from "@angular/core";
//import HttpClient
//HttpClient is used to make the Rest Calls
import { HttpClient } from "@angular/common/http";
//import rxjs package
import "rxjs/Rx";


//import Observable
import { Observable } from "rxjs";




//import Customers Interface
import Customers from "../common/Customers";
//import CUSTOMERS_URL
import CUSTOMERS_URL from "../common/URLS";
//use Injectable
@Injectable()
//export the class
export class customersService{
    //create the object to HttpClient
    constructor(private _http:HttpClient){}

    //create the public function
    public getCustomers():Observable<Customers[]>{
        return this._http.get(CUSTOMERS_URL)
                   .pipe(map(posRes=>{
                       return <Customers[]>posRes.json().records;
                   })).catch(this._errorCallBack);
    };
    public _errorCallBack = (err)=>{
        return Observable.throw(err ||  "Internal Server Error !!!");
    };
}